const register = require("./register");

module.exports.handler = async (event) => {
  var result = await register.run();
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: JSON.parse(result),
      input: event,
    }, null, 2),
  };
};