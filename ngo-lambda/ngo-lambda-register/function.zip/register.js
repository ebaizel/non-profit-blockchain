/*
# Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# 
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# or in the "license" file accompanying this file. This file is distributed 
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
# express or implied. See the License for the specific language governing 
# permissions and limitations under the License.
#
*/

// Register and enroll a user.  Persists secrets in AWS Parameter Store

var fs = require("fs");
var path = require('path');
var Fabric_Client = require('fabric-client');
const awsParamStore = require( 'aws-param-store' );

// setup the fabric network
var fabric_client = new Fabric_Client();
var channel = fabric_client.newChannel('mychannel2');
var orgcert = fs.readFileSync("./certs/managedblockchain-tls-chain.pem", "utf8");
var peer = fabric_client.newPeer('grpcs://nd-wlsp43i3jbgxvk73dyatmabe5y.m-v6cgadwqazhgji663wfooscpvq.n-gp2swutyoracdczosa7mdqc5ra.managedblockchain.us-east-1.amazonaws.com:30003', {pem: orgcert});
channel.addPeer(peer);

const ADMIN_USERNAME_KEY = 'amb.n-GP2SWUTYORACDCZOSA7MDQC5RA.admin.username';
const ADMIN_PASSWORD_KEY = 'amb.n-GP2SWUTYORACDCZOSA7MDQC5RA.admin.password';

const USER_PASSWORD_KEY_PREFIX = 'amb.n-GP2SWUTYORACDCZOSA7MDQC5RA.user.password.';

// Helper function to get admin user info
async function getAdminInfo() {
    return awsParamStore.getParameters([ADMIN_USERNAME_KEY, ADMIN_PASSWORD_KEY], { region: 'us-east-1' } )
    .then( (parameters) => {
        console.log("got admin parameters, " + JSON.stringify(parameters));
        return {
            username: parameters.Parameters[0].Value,
            password: parameters.Parameters[1].Value
        };
    })
}

function getUserPasswordKey(username) {
    return USER_PASSWORD_KEY_PREFIX + username;
}

async function getUserInfo(username) {
    return awsParamStore.getParameter(getPasswordKey(username), { region: 'us-east-1' } )
    .then( (parameter) => {
        console.log("got user parameters, " + JSON.stringify(parameter));
        if (parameter.Parameters.length == 0) return {};
        return {
            username: parameters.Parameters[0].Value,
            password: parameters.Parameters[1].Value
        };
    })
}

async function setAdminContext(client) {
    const {username, password} = await getAdminInfo();
    console.log("setting admin context for " + username);
    return await client.setUserContext({username: admins[0].username, password: admins[0].secret});
}

async function putUserInfo(username, secret) {
    console.log("putting user info " + username)
    console.log("putting user info " + secret)
    await awsParamStore.putParameter(getUsernameKey(username), secret, "SecureString", { region: 'us-east-1' });
}

var store_path = path.join(__dirname, 'hfc-key-store');

module.exports.run  =  async  (event)  =>  {
    // Do we need this persistence set up?
    return Fabric_Client.newDefaultKeyValueStore({ path: store_path }).then(async (state_store) => {
        fabric_client.setStateStore(state_store);
        var crypto_suite = Fabric_Client.newCryptoSuite();
        var crypto_store = Fabric_Client.newCryptoKeyStore({path: store_path});
        crypto_suite.setCryptoKeyStore(crypto_store);
        fabric_client.setCryptoSuite(crypto_suite);

        let adminUserObj = await setAdminContext(fabric_client);
        let caClient = client.getCertificateAuthority();

        logger.info('##### registerUser - Successfully got the secret for user %s', username);
        console.log("SECRET IS " + secret);
        console.log("GOT event " + event);
        let username = event.username || 'daisy';
        
        let secret = await caClient.register({
            enrollmentID: username
        }, adminUserObj);

        await putUserInfo(username, secret);

        return {
            success: true,
            secret,
            message: username + ' enrolled Successfully',
        };
    });
};   